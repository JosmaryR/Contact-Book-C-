﻿

using System;
using System.Collections.Generic;
using System.Text;

namespace ContactBookGiTVersion
{

    using static ContactComparer;

    public class ContactBook
    {
        public const string YES = "Y";
        public const string NO = "N";

        public readonly string[] YES_NO = new string[] { YES, NO };

        public const string NEXT_PAGE = "+";
        public const string PREV_PAGE = "-";
        public const string GOTO_PAGE = "G";
        public const string PAGE_SIZE = "S";
        public const string CREATE_CONTACT = "C";
        public const string REVIEW_CONTACT = "R";
        public const string UPDATE_CONTACT = "U";
        public const string DELETE_CONTACT = "D";
        public const string FIND_CONTACTS = "F";
        public const string ORDER_CONTACTS = "O";
        public const string DEDUPLICATE_CONTACTS = "M";
        public const string EXIT = "X";

        public readonly string[] COMMANDS = new string[]
        {
        NEXT_PAGE, PREV_PAGE, GOTO_PAGE, PAGE_SIZE, CREATE_CONTACT,
        REVIEW_CONTACT, UPDATE_CONTACT, DELETE_CONTACT, FIND_CONTACTS,
        ORDER_CONTACTS, DEDUPLICATE_CONTACTS,   EXIT
        };

        private List<Contact> allContacts;
        private List<Contact> filteredContacts;
        private int page;
        private int size;
        private bool isExit;

        public ContactBook(List<Contact> contacts = null!)
        {
            allContacts = (contacts == null) ? new List<Contact>() : contacts;
            filteredContacts = allContacts;
            page = 1;
            size = 10;
            isExit = false;
        }

        public void Start()
        {
            ShowWelcomeScreen();

            string input;
            do
            {
                do
                {
                    ShowContacts();
                    ShowInputOptions();
                    input = GetInput();
                }
                while (!IsValidInput(input));

                ProcessInput(input);
            }
            while (!ConfirmExit());

            ShowExitScreen();
        }

        private void ShowWelcomeScreen()
        {
            Console.WriteLine("Welcome to Jos Contact Book");
            PressEnterContinue();
        }

        private void ShowContacts()
        {
            Console.Clear();
            ShowContacts(filteredContacts, page, size);
        }

        private void ShowContacts(List<Contact> contacts, int page, int size)
        {
            if (contacts.Count <= 0)
            {
                Console.WriteLine("No contacts found.");
            }
            else
            {
                int indexCol = Math.Max("#".Length, contacts.Count.ToString().Length);
                int fnameCol = Math.Max("First Name".Length, contacts.Max(c => c.GetFName()?.Length ?? 0));
                int lnameCol = Math.Max("Last Name".Length, contacts.Max(c => c.GetLName()?.Length ?? 0));
                int phoneCol = Math.Max("Phone".Length, contacts.Max(c => c.GetPhone()?.Length ?? 0));
                int emailCol = Math.Max("Email".Length, contacts.Max(c => c.GetEmail()?.Length ?? 0));

                Console.WriteLine(""
                + "{0, " + -indexCol + "}  "
                + "{1, " + -fnameCol + "}  "
                + "{2, " + -lnameCol + "}  "
                + "{3, " + -phoneCol + "}  "
                + "{4, " + -emailCol + "}  ",
                "#", "First Name", "Last Name", "Phone", "Email");

                Console.WriteLine(new string('─', (indexCol + 2 + fnameCol + 2 + lnameCol + 2 + phoneCol + 2 + emailCol)));

                int n = contacts.Count;
                int pageCount = PageCount(contacts, size);
                int s = Math.Clamp((page - 1) * size, 0, n);
                int e = Math.Clamp(s + size, 0, n);

                for (int i = s; i < e; i++)
                {
                    Contact c = contacts[i];

                    Console.WriteLine(""
                    + "{0, " + -indexCol + "}  "
                    + "{1, " + -fnameCol + "}  "
                    + "{2, " + -lnameCol + "}  "
                    + "{3, " + -phoneCol + "}  "
                    + "{4, " + -emailCol + "}  ",
                    (i + 1), c.GetFName(), c.GetLName(), c.GetPhone(), c.GetEmail());
                }

                for (int i = 0; i < size - e + s; i++)
                {
                    Console.WriteLine();
                }

                Console.WriteLine();
                Console.WriteLine($"Page {page} of {pageCount} ({s + 1}-{e} of {n})");
            }
        }

        private void ShowInputOptions()
        {
            string inputOptions = ""
            + $"[{NEXT_PAGE}] Next Page | [{CREATE_CONTACT}] Create Contact | [{DELETE_CONTACT}] Delete Contact | [{DEDUPLICATE_CONTACTS}] Deduplicate Contacts\n"
            + $"[{PREV_PAGE}] Prev Page | [{REVIEW_CONTACT}] Review Contact | [{FIND_CONTACTS}]  Find Contacts | [{PAGE_SIZE}] Change Page Size\n"
            + $"[{GOTO_PAGE}] Go to Page| [{UPDATE_CONTACT}] Update Contact | [{ORDER_CONTACTS}] Order Contacts | [{EXIT}] Exit\n"
            + $"\n> ";

            Console.WriteLine();
            Console.Write(inputOptions);
        }

        private string GetInput()
        {
            return Console.ReadLine()!.ToUpper();
        }

        private bool IsValidInput(string input)
        {
            if (!COMMANDS.Contains(input))
            {
                Console.WriteLine("ERROR: Invalid input. Please try again.");
                PressEnterContinue();
                return false;
            }
            else
            {
                return true;
            }
        }

        private void ProcessInput(string input)
        {
            switch (input)
            {
                case NEXT_PAGE: NextPage(); break;
                case PREV_PAGE: PrevPage(); break;
                case GOTO_PAGE: GotoPage(); break;
                case PAGE_SIZE: PageSize(); break;
                case CREATE_CONTACT: CreateContact(); break;
                case REVIEW_CONTACT: ReviewContact(); break;
                case UPDATE_CONTACT: UpdateContact(); break;
                case DELETE_CONTACT: DeleteContact(); break;
                case FIND_CONTACTS: FindContacts(); break;
                case ORDER_CONTACTS: OrderContacts(); break;
                case DEDUPLICATE_CONTACTS: DeduplicateContacts(); break;
                case EXIT: Exit(); break;
                default: break;
            }
        }

        private bool ConfirmExit()
        {
            return (isExit) ? isExit = Confirm("Do you want to exit?", NO) : false;
        }

        private void ShowExitScreen()
        {
            Console.Clear();
            Console.WriteLine("Thank you for using and trusting Jos Contact Book");
        }

        private void PressEnterContinue()
        {
            Console.Write("Press ENTER to continue.");
            while (Console.ReadKey(true).Key != ConsoleKey.Enter) ;
        }

        private void NextPage()
        {
            NextPage(filteredContacts, ref page, size);
        }

        private void NextPage(List<Contact> contacts, ref int page, int size)
        {
            page = Math.Clamp(page + 1, 1, PageCount(contacts, size));
        }

        private void PrevPage()
        {
            PrevPage(filteredContacts, ref page, size);
        }

        private void PrevPage(List<Contact> contacts, ref int page, int size)
        {
            page = Math.Clamp(page - 1, 1, PageCount(contacts, size));
        }

        private void GotoPage()
        {
            GotoPage(filteredContacts, ref page, size);
        }

        private void GotoPage(List<Contact> contacts, ref int page, int size)
        {
            page = GetInt("Enter page", 1, PageCount(contacts, size));
        }

        private void PageSize()
        {
            PageSize(ref page, ref size);
        }

        private void PageSize(ref int page, ref int size)
        {
            int max = Console.WindowHeight - 10;
            size = GetInt("Enter page size", 1, max);
            page = 1;
        }

        private void CreateContact()
        {
            Console.Clear();
            Console.WriteLine(new string('#', 80));
            Console.WriteLine("Create Contact");
            Console.WriteLine(new string('#', 80));
            Console.WriteLine();

            Console.Write("Enter first name: ");
            string fname = Console.ReadLine()!;
            Console.Write("Enter last name: ");
            string lname = Console.ReadLine()!;
            Console.Write("Enter phone: ");
            string phone = Console.ReadLine()!;
            Console.Write("Enter email: ");
            string email = Console.ReadLine()!;

            Console.WriteLine();

            if (Confirm("Do you want to create this contact?", YES))
            {
                Contact c = new Contact(fname, lname, phone, email);
                filteredContacts.Add(c);
                page = PageCount(filteredContacts, size);
                Console.WriteLine("Operation successful: Contact created.");
            }
            else
            {
                Console.WriteLine("Operation cancelled: Contact not created.");
            }

            Console.WriteLine();
            PressEnterContinue();
        }

        private void ReviewContact()
        {
            int index = GetInt("Enter index", 1, filteredContacts.Count) - 1;

            Console.Clear();

            Console.WriteLine(new string('#', 80));
            Console.WriteLine("Review Contact");
            Console.WriteLine(new string('#', 80));
            Console.WriteLine();

            ReviewContact(filteredContacts, index);

            Console.WriteLine();
            PressEnterContinue();
        }

        private void ReviewContact(List<Contact> contacts, int index)
        {
            Contact c = contacts[index];

            Console.WriteLine($"First name: {c.GetFName()}");
            Console.WriteLine($" Last name: {c.GetLName()}");
            Console.WriteLine($"     Phone: {c.GetPhone()}");
            Console.WriteLine($"     Email: {c.GetEmail()}");
        }

        private void UpdateContact()
        {
            int index = GetInt("Enter index", 1, filteredContacts.Count) - 1;

            Console.Clear();

            Console.WriteLine(new string('#', 80));
            Console.WriteLine("Update Contact");
            Console.WriteLine(new string('#', 80));
            Console.WriteLine();

            UpdateContact(index);

            Console.WriteLine();
            PressEnterContinue();
        }

        private void UpdateContact(int index)
        {
            Contact c = filteredContacts[index];

            string fname = c.GetFName();
            string lname = c.GetLName();
            string phone = c.GetPhone();
            string email = c.GetEmail();

            ReviewContact(filteredContacts, index);

            Console.WriteLine();

            if (Confirm("Do you want to edit the first name?", NO))
            {
                Console.Write("Enter first name: ");
                fname = Console.ReadLine()!;
            }

            if (Confirm("Do you want to edit the last name?", NO))
            {
                Console.Write("Enter last name: ");
                lname = Console.ReadLine()!;
            }

            if (Confirm("Do you want to edit the phone?", NO))
            {
                Console.Write("Enter phone: ");
                phone = Console.ReadLine()!;
            }

            if (Confirm("Do you want to edit the email?", NO))
            {
                Console.Write("Enter email: ");
                email = Console.ReadLine()!;
            }

            Console.WriteLine();

            if (Confirm("Do you want to update this contact?", NO))
            {
                c.SetFName(fname);
                c.SetLName(lname);
                c.SetPhone(phone);
                c.SetEmail(email);
                Console.WriteLine("Operation successful: Contact updated.");
            }
            else
            {
                Console.WriteLine("Operation cancelled: Contact not updated.");
            }
        }

        private void DeleteContact()
        {
            int index = GetInt("Enter index", 1, filteredContacts.Count) - 1;

            Console.Clear();

            Console.WriteLine(new string('#', 80));
            Console.WriteLine("Delete Contact");
            Console.WriteLine(new string('#', 80));
            Console.WriteLine();

            DeleteContact(index);

            Console.WriteLine();
            PressEnterContinue();
        }

        private void DeleteContact(int index)
        {
            Contact c = filteredContacts[index];

            ReviewContact(filteredContacts, index);

            Console.WriteLine();

            if (Confirm("Do you want to delete this contact?", NO))
            {
                filteredContacts.Remove(c);
                Console.WriteLine("Operation successful: Contact deleted.");
            }
            else
            {
                Console.WriteLine("Operation cancelled: Contact not deleted.");
            }
        }

        private void FindContacts()
        {
            Console.Write("Enter search term (Clear): ");
            string searchTerm = Console.ReadLine()!.ToLower();

            Console.WriteLine();

            if (Confirm("Do you want to search contacts?", YES))
            {
                filteredContacts = allContacts.FindAll(c =>
                    (c.GetFName() + c.GetLName() + c.GetPhone() + c.GetEmail()).ToLower().Contains(searchTerm));

                page = 1;

                Console.WriteLine("Operation successful: Contacts searched.");
            }
            else
            {
                Console.WriteLine("Operation cancelled: Contacts not searched.");
            }

            PressEnterContinue();
        }

        private void OrderContacts()
        {
            SortType[] sortTypes = new SortType[]
            {
            SortType.FName, SortType.LName, SortType.Phone, SortType.Email
            };

            int index = GetInt("Sort contacts by [0] First Name [1] Last Name [2] Phone [3] Email", 0, 3);

            ContactComparer ccp = new ContactComparer(sortTypes[index]);
            allContacts.Sort(ccp);
            filteredContacts.Sort(ccp);
        }

        private void DeduplicateContacts()
        {
            List<List<Contact>> duplicateGroups = ContactMerger.FindDuplicates(allContacts);
            List<Contact> temp = new List<Contact>();

            foreach (var group in duplicateGroups)
            {
                if (group.Count > 1)
                {
                    Console.Clear();
                    Console.WriteLine(new string('#', 80));
                    Console.WriteLine("Duplicate Contacts");
                    Console.WriteLine(new string('#', 80));
                    Console.WriteLine();
                    ShowContacts(group, 1, group.Count);
                    int fnameIndex = GetInt("Enter first name index", 1, group.Count) - 1;
                    int lnameIndex = GetInt("Enter last name index", 1, group.Count) - 1;
                    int phoneIndex = GetInt("Enter phone index", 1, group.Count) - 1;
                    int emailIndex = GetInt("Enter email index", 1, group.Count) - 1;

                    Contact merged = new Contact();
                    merged.SetFName(group[fnameIndex].GetFName());
                    merged.SetLName(group[lnameIndex].GetLName());
                    merged.SetPhone(group[phoneIndex].GetPhone());
                    merged.SetEmail(group[emailIndex].GetEmail());

                    Console.WriteLine();
                    Console.WriteLine(new string('#', 80));
                    Console.WriteLine("Merged Contact");
                    Console.WriteLine(new string('#', 80));
                    Console.WriteLine();

                    List<Contact> mergedLS = new List<Contact> { merged };
                    ShowContacts(mergedLS, 1, 1);
                    Console.WriteLine();

                    if (Confirm("Do you want to merge these contacts?", NO))
                    {
                        temp.Add(merged);
                        Console.WriteLine("Operation successful: Contacts merged.");
                    }
                    else
                    {
                        temp.AddRange(group);
                        Console.WriteLine("Operation cancelled: Contacts not merged.");
                    }

                    Console.WriteLine();
                    PressEnterContinue();
                }
                else
                {
                    temp.AddRange(group);
                }
            }

            Console.WriteLine();

            if (Confirm("Do you want to apply all merges to the contact list?", NO))
            {
                allContacts = filteredContacts = temp;
                Console.WriteLine("Operation successful: Contacts deduplicated.");
            }
            else
            {
                Console.WriteLine("Operation cancelled: Contacts not deduplicated.");
            }

            Console.WriteLine();
            PressEnterContinue();
        }

        private void Exit()
        {
            isExit = true;
        }

        private int GetInt(string prompt, int min, int max)
        {
            string options = $"{min}-{max}";

            Console.Write(prompt + $" [{options}] ");
            string answer = Console.ReadLine()!;
            int value;

            while (!int.TryParse(answer, out value) || value < min || value > max)
            {
                Console.WriteLine("ERROR: Invalid option. Please try again.");
                Console.Write(prompt + $" [{options}] ");
                answer = Console.ReadLine()!;
            }

            return value;
        }

        private string GetOption(string prompt, string[] validOptions, string defaultOption)
        {
            string options = string.Join('/', validOptions);

            Console.Write(prompt + $" [{options}] ({defaultOption}) ");
            string option = Console.ReadLine()!.ToUpper();

            if (string.IsNullOrWhiteSpace(option)) { option = defaultOption; }

            while (!validOptions.Contains(option))
            {
                Console.WriteLine("ERROR: Invalid option. Please try again.");
                Console.Write(prompt + $" [{options}] ({defaultOption}) ");
                option = Console.ReadLine()!.ToUpper();

                if (string.IsNullOrWhiteSpace(option)) { option = defaultOption; }
            }

            return option;
        }

        private bool Confirm(string prompt, string defaultOption)
        {
            return GetOption(prompt, YES_NO, defaultOption) == YES;
        }

        private static int PageCount(List<Contact> contacts, int size)
        {
            return (int)Math.Max(1, Math.Ceiling(contacts.Count / (double)size));
        }
    }
}

